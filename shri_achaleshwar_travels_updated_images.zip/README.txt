SHRI ACHALESHWAR TOUR & TRAVELS WEBSITE (UPDATED & VERIFIED)

Netlify URL: https://shriachaleshwartourandtravels.netlify.app/

CHANGES & FIXES APPLIED:
1. Fleet Section Vehicle Correction:
   - Dzire Card: Now accurately features the real Maruti Suzuki Dzire photo (provided by user) with title "Maruti Suzuki Dzire" and specs (4+1 Seater AC Sedan).
   - Ertiga Card: Features the Maruti Suzuki Ertiga 7-seater photo (6+1 Seater Dual AC).
   - Alto Card: Corrected to feature the Maruti Suzuki Alto hatchback photo (previously mislabeled under Dzire) with title "Maruti Suzuki Alto" (4+1 Seater Hatchback).
   - Eeco Card: Features the Maruti Suzuki Eeco (7 Seater Utility Van).
2. Call Now & WhatsApp Buttons Added:
   - Sticky Topbar with click-to-call numbers (+91 96694 39781 & +91 87706 65934) and WhatsApp chat.
   - Header with Call Now and WhatsApp quick-action buttons.
   - Hero Section with high-visibility Call Now (+91 96694 39781) and WhatsApp chat buttons.
   - Each Vehicle Card now has individual "Call to Book" and "WhatsApp" buttons.
   - Desktop Floating Action Dock with pulsing Call and WhatsApp buttons.
   - Mobile Sticky Bottom Action Bar with 1-tap Call and WhatsApp buttons.
   - Direct Call and WhatsApp action buttons on Contact cards.
3. Sitemap & SEO:
   - sitemap.xml updated with https://shriachaleshwartourandtravels.netlify.app/
   - robots.txt updated with correct sitemap URL.
   - Canonical URL, OpenGraph tags, and Schema.org TaxiService JSON-LD structured data added.
4. Images:
   - User-supplied Dzire car photo integrated into /images/dzire.webp and gallery.
   - User-supplied Ertiga CNG photo integrated into /images/ertiga-cng.webp and hero/gallery.
   - Alto car photo saved to /images/alto.webp.
5. Animations:
   - Added smooth staggered scroll reveal with cubic-bezier easing.
   - Subtle pulsing halo/rings on Call and WhatsApp buttons.
   - Smooth 3D elevation and image zoom on vehicle cards and gallery.
   - Header blur and shadow transition on scroll.

DEPLOYMENT:
Simply extract this zip and upload the folder contents directly to Netlify (drag and drop to Netlify).


LATEST UPDATE (16 Nov 2026): Added FAQ accordion and FAQ structured data, responsive tablet/mobile/iOS safe-area refinements, animated floating contact actions, Other Vehicles enquiry card, and refreshed customer-supplied Ertiga and Eeco photographs.

NETLIFY DEPLOY: Extract this ZIP and drag the folder containing index.html, styles.css, script.js, images/, sitemap.xml and robots.txt into Netlify Deploys. Keep the images folder beside index.html.
