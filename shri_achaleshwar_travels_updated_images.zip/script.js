// Header scroll effect
const header = document.querySelector('.site-header');
window.addEventListener('scroll', () => {
  if (window.scrollY > 40) {
    header?.classList.add('scrolled');
  } else {
    header?.classList.remove('scrolled');
  }
}, { passive: true });

// Mobile Navigation Toggle
const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav-links');

if (menuButton && nav) {
  menuButton.addEventListener('click', (e) => {
    e.stopPropagation();
    const open = nav.classList.toggle('open');
    menuButton.setAttribute('aria-expanded', String(open));
    menuButton.textContent = open ? '✕' : '☰';
  });

  nav.querySelectorAll('a').forEach(a => {
    a.addEventListener('click', () => {
      nav.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.textContent = '☰';
    });
  });

  document.addEventListener('click', (e) => {
    if (nav.classList.contains('open') && !nav.contains(e.target) && !menuButton.contains(e.target)) {
      nav.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.textContent = '☰';
    }
  });
}

// Current Year in Footer
const yearElem = document.getElementById('year');
if (yearElem) {
  yearElem.textContent = new Date().getFullYear();
}

// Minimum date for booking form
const dateInput = document.querySelector('input[name="date"]');
if (dateInput) {
  const today = new Date();
  const localDate = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  dateInput.min = localDate;
  if (!dateInput.value) {
    dateInput.value = localDate;
  }
}

// Booking Form WhatsApp Submission
const form = document.getElementById('bookingForm');
if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!form.reportValidity()) return;

    const d = new FormData(form);
    const msg = [
      '🚗 *TRIP ENQUIRY - SHRI ACHALESHWAR TOUR & TRAVELS*',
      '----------------------------------------',
      `👤 *Name:* ${d.get('name')}`,
      `📞 *Mobile:* ${d.get('phone')}`,
      `📍 *Pickup:* ${d.get('pickup')}`,
      `🎯 *Destination:* ${d.get('destination')}`,
      `📅 *Journey Date:* ${d.get('date')}`,
      `🚘 *Vehicle Preference:* ${d.get('vehicle')}`,
      `📝 *Details:* ${d.get('message') || 'None'}`,
      '----------------------------------------',
      'Please share available cabs and fare details.'
    ].join('\n');

    window.open('https://wa.me/919669439781?text=' + encodeURIComponent(msg), '_blank', 'noopener');
  });
}

// Enhanced IntersectionObserver for Staggered Animations
const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const delay = entry.target.getAttribute('data-delay') || '0';
        setTimeout(() => {
          entry.target.classList.add('visible');
        }, parseInt(delay, 10));
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealItems.forEach((item, index) => {
    if (!item.hasAttribute('data-delay')) {
      const siblingIndex = Array.from(item.parentNode.children).indexOf(item);
      item.setAttribute('data-delay', String((siblingIndex % 4) * 120));
    }
    observer.observe(item);
  });
} else {
  revealItems.forEach(item => item.classList.add('visible'));
}
